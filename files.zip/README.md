# Title Machine — Alex Eala Channel

A Streamlit app that generates viral YouTube title variations based on competitor outlier topics.

## Setup

### 1. Add your Anthropic API key in Streamlit Cloud
Go to your app's **Settings → Secrets** and add:

```toml
ANTHROPIC_API_KEY = "sk-ant-your-key-here"
```

### 2. Files in this repo
- `app.py` — main Streamlit app
- `requirements.txt` — dependencies

## Local development

```bash
pip install streamlit anthropic
# Create .streamlit/secrets.toml with your API key
streamlit run app.py
```
